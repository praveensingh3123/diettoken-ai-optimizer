# DietToken 🥤🚀

**DietToken** is the world's most efficient local-first engine for code-aware AI context management. Slash your LLM bills by 50%–70% without breaking your code logic.

---

## 💎 DietToken Pro (Coming Soon)
Take your token optimization to the next level:
- **Unlimited Semantic Mapping:** Compress every identifier, not just long ones.
- **Advanced Knowledge Graph:** Export architectural maps to external AI tools.
- **Enterprise Privacy:** Custom exclusion rules and proprietary language support.
- **Team Dashboard:** Cumulative savings tracking for entire engineering teams.

---

## 🛠 Features
- **Deterministic AST Compression:** Safe, lossless surgery on your source code using Tree-sitter WASM.
- **Semantic Reverse Mapping:** Intelligent identifier shortening with local lookup.
- **Integrated Knowledge Graph:** Automatic dependency tracking for AI agents.
- **MCP Native:** Deep integration with Claude Desktop, Deputy Dev, and more.
- **100% Local-First:** Your code stays on your machine. Always.

## 📦 Installation
1. Download the latest `.vsix` from the releases page.
2. Open VS Code and run: `Extensions: Install from VSIX...`
3. Select the `diet-token-optimizer-x.x.x.vsix` file.

## 🚀 How it Works
1. **Level 1 (Syntactic):** Removes comments and redundant whitespace.
2. **Level 2 (Semantic):** Uses **Reverse Mapping** to shorten identifiers while preserving logic.
3. **Knowledge Graph:** Builds a map of dependencies to prune context bloat.

## 📊 Telemetry
DietToken respects your privacy. We collect **anonymous, cumulative savings data** (tokens saved only) to improve the compression engine. No code, filenames, or personal data ever leaves your machine.

---
Built with ❤️ by Praveen Singh.
