# DietToken Public Repository Architecture

This guide explains how to initialize and maintain the **Public "Thin Shell" Repository** for DietToken. 

## The Strategy
To build trust with Enterprise CTOs and Security Teams without exposing your proprietary IP (the compression algorithm), we use the "Thin Shell + Black Box" architecture.

1. **The Public Repo**: Contains the `mcp-server`, the `vscode-extension`, and the offline `cli` tool.
2. **The Black Box**: The core compression logic is compiled and bundled into an obfuscated Javascript binary (`diettoken-engine.js`). The public repo consumes this as a dependency.

This proves that **zero code leaves the local machine** because the community can audit the network requests in the public shell, while your IP remains secure inside the black box.

## How to Initialize the Public Repo

Once you are ready to publish the open-source shells:

1. **Create a new GitHub Repository**: e.g., `diettoken-open` or just `diettoken` (if you rename the private one to `diettoken-core`).
2. **Move the Shell Code**: Move the following directories from the private repo to the new public repo:
   - `src/cli/`
   - `src/extension.ts`
   - `src/mcp-server.ts`
3. **Consume the Engine**:
   - In the private repo, run `npm run build-engine`. This creates `out/core/diettoken-engine.js`.
   - You can either publish this to a private NPM registry (and the public repo installs it), or you can manually copy `diettoken-engine.js` into the public repo's `lib/` folder.
   - Update imports in the public repo to point to the engine:
     ```typescript
     import { AstCompressor, countTokens } from './lib/diettoken-engine.js';
     ```

## The CLI Demo (Proof of Value)
The public repo will contain the `diettoken` CLI tool.
CTOs can run it offline on their own machines to see the exact token and dollar savings.

```bash
# Run locally to audit savings
npx diettoken /path/to/enterprise/codebase
```

The output will be a detailed, CFO-ready report proving the ROI of DietToken.
