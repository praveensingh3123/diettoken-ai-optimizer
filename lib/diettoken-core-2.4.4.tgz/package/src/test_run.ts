import { KnowledgeGraph } from './graph/KnowledgeGraph';
import { AstCompressor } from './compression/AstCompressor';
import { ReverseMapper } from './compression/ReverseMapper';
import * as path from 'path';

async function run() {
    console.log("Initializing Graph...");
    const graph = KnowledgeGraph.getInstance();
    await graph.initialize(path.resolve(__dirname, '..'));

    console.log("Graph Initialized. Testing AstCompressor...");
    const compressor = new AstCompressor(new ReverseMapper());

    const code = `
# This is a giant python comment that should be removed
from torpedo import CONFIG, Task, ParallelRunner
from torpedo.logging import log_error, log_info
from app.managers.header.header import HeaderManager
from app.managers.orders.orders import OrdersManager

<ext_safe>
# THIS BLOCK IS SAFE
x = 10
</ext_safe>

def calculateTotalRevenueAndTax(val1, val2):
    # Math operation
    return val1 + val2
    `;

    // update file node so KnowledgeGraph has it
    await graph.updateFileNode('/test.py', code);
    
    console.log("Dependencies:", JSON.stringify(graph.getFileDependencies('/test.py')));

    const compressed = await compressor.compress(code);
    console.log("Compressed Code:\\n", compressed);
    
    process.exit(0);
}

run().catch(console.error);
