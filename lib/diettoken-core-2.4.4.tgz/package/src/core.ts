export { AstCompressor } from './compression/AstCompressor';
export { ReverseMapper } from './compression/ReverseMapper';
export { CacheSimulator } from './compression/CacheSimulator';
export { PromptCompressor } from './compression/PromptCompressor';
export { KnowledgeGraph } from './graph/KnowledgeGraph';

// Helper to count tokens using js-tiktoken safely
export function countTokens(text: string): number {
    if (!text) return 0;
    try {
        const { encodingForModel } = require("js-tiktoken");
        const enc = encodingForModel("gpt-4o");
        return enc.encode(text).length;
    } catch (e) {
        return Math.ceil(text.length / 4);
    }
}
