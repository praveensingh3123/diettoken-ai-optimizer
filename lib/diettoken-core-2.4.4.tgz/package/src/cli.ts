#!/usr/bin/env node
import * as fs from 'fs';
import * as path from 'path';
import { KnowledgeGraph } from './graph/KnowledgeGraph';
import { AstCompressor } from './compression/AstCompressor';
import { ReverseMapper } from './compression/ReverseMapper';
import { countTokens } from './core';

async function run() {
    const args = process.argv.slice(2);
    if (args[0] !== 'verify' || !args[1]) {
        console.error("Usage: diettoken verify <filepath>");
        process.exit(1);
    }

    const targetFile = args[1];
    const filePath = path.resolve(process.cwd(), targetFile);
    if (!fs.existsSync(filePath)) {
        console.error(`File not found: ${targetFile}`);
        process.exit(1);
    }

    const sourceCode = fs.readFileSync(filePath, 'utf-8');
    const originalTokens = countTokens(sourceCode);

    // Initialize graph and compressor silently
    const graph = KnowledgeGraph.getInstance();
    const packageRoot = path.resolve(__dirname, '..');
    await graph.initialize(packageRoot);
    await graph.updateFileNode(filePath, sourceCode);

    const compressor = new AstCompressor(new ReverseMapper());
    const compressedCode = await compressor.compress(sourceCode, undefined, filePath);
    const compressedTokens = countTokens(compressedCode);

    const tokensSaved = originalTokens - compressedTokens;
    const compressionRatio = originalTokens > 0 ? ((tokensSaved / originalTokens) * 100).toFixed(1) : "0.0";

    console.log(`
──────────────────────────────────────
DietToken Verification Report
──────────────────────────────────────
File:             ${targetFile}
Original tokens:  ${originalTokens.toLocaleString()}  (measured via tiktoken)
Compressed tokens: ${compressedTokens.toLocaleString()}  (measured via tiktoken)
Tokens saved:     ${tokensSaved.toLocaleString()}
Compression ratio: ${compressionRatio}%
──────────────────────────────────────
Measurement method: tiktoken (OpenAI's own tokenizer)
This report runs 100% offline. Nothing was sent anywhere.
You can verify the token counts independently at:
platform.openai.com/tokenizer
──────────────────────────────────────
`);
    process.exit(0);
}

run().catch(e => {
    console.error("Verification failed:", e.message);
    process.exit(1);
});
