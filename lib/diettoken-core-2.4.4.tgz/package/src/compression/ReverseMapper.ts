export interface RemapDictionary {
    [shortenedName: string]: string; // e.g., "_t1" -> "computeTotalPriceAndApplyDiscount"
}

export class ReverseMapper {
    private activeDictionary: RemapDictionary = {};
    private tokenCounter = 0;
    private streamBuffer = "";

    /**
     * Level 2 Compression: Scans the prompt, identifies long identifiers, 
     * and shortens them while maintaining a dictionary to reverse it.
     */
    public compress(prompt: string): { compressedPrompt: string, dictionary: RemapDictionary } {
        let compressedPrompt = prompt;
        const newDict: RemapDictionary = {};
        
        // Extract long tokens (e.g., camelCase/snake_case variables longer than 12 chars)
        // In a production Tree-sitter build, this would ONLY target AST Nodes of type 'identifier'
        const tokensToShorten = this.extractTokens(prompt);
        
        tokensToShorten.forEach(token => {
            // Avoid shortening common JS/Python/Go reserved keywords just in case
            if (this.isReservedKeyword(token)) return;

            const shortToken = this.generateShortToken();
            newDict[shortToken] = token;
            this.activeDictionary[shortToken] = token; // Store globally for this request session
            
            // Replace all instances
            const regex = new RegExp(`\\b${token}\\b`, 'g');
            compressedPrompt = compressedPrompt.replace(regex, shortToken);
        });

        return { compressedPrompt, dictionary: newDict };
    }

    /**
     * Reverse Map for Streaming Chunks: 
     * Intercepts SSE chunks coming back from LLM and expands short tokens back to original form.
     */
    public decompressChunk(chunk: string): string {
        this.streamBuffer += chunk;
        
        // If the buffer ends with something that looks like it COULD be an incomplete token
        // e.g., ends with "_", "_t", or "_t" followed by numbers
        if (/_$|_t\d*$/.test(this.streamBuffer)) {
            return ""; // Hold this chunk, wait for more
        }

        let decompressed = this.streamBuffer;
        for (const [shortToken, originalToken] of Object.entries(this.activeDictionary)) {
            const regex = new RegExp(`\\b${shortToken}\\b`, 'g');
            decompressed = decompressed.replace(regex, originalToken);
        }
        
        this.streamBuffer = "";
        return decompressed;
    }

    public flush(): string {
        if (!this.streamBuffer) return "";
        let decompressed = this.streamBuffer;
        for (const [shortToken, originalToken] of Object.entries(this.activeDictionary)) {
            const regex = new RegExp(`\\b${shortToken}\\b`, 'g');
            decompressed = decompressed.replace(regex, originalToken);
        }
        this.streamBuffer = "";
        return decompressed;
    }

    private extractTokens(text: string): string[] {
        // Matches typical long identifiers like 'MyAbstractFactoryImpl'
        const matches = text.match(/\b[a-zA-Z_]\w{11,}\b/g) || [];
        return [...new Set(matches)]; // Unique tokens only
    }

    private generateShortToken(): string {
        this.tokenCounter++;
        return `_t${this.tokenCounter}`;
    }

    private isReservedKeyword(word: string): boolean {
        const reserved = new Set(['constructor', 'prototype', 'return', 'function', 'class']);
        return reserved.has(word);
    }

    public clearSession() {
        this.activeDictionary = {};
        this.tokenCounter = 0;
        this.streamBuffer = "";
    }

    /**
     * Replaces compressed tokens (_t1, _t2, etc.) with their original long identifiers.
     * Used for calculating the true original token count in multi-turn conversations.
     */
    public expand(text: string): string {
        if (!text) return text;
        
        let expanded = text;
        const tokens = Object.keys(this.activeDictionary).sort((a, b) => {
            const numA = parseInt(a.substring(2), 10);
            const numB = parseInt(b.substring(2), 10);
            return numB - numA;
        });

        for (const token of tokens) {
            const original = this.activeDictionary[token];
            if (original) {
                const regex = new RegExp(`\\b${token}\\b`, 'g');
                expanded = expanded.replace(regex, original);
            }
        }
        return expanded;
    }
}
