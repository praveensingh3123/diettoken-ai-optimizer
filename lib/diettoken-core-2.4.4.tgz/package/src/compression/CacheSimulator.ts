/**
 * CacheSimulator: Simulates LLM provider-level prompt caching discounts locally.
 *
 * Since DietToken operates as an MCP tool inside IDEs (Cursor, Antigravity, DeputyDev)
 * and cannot intercept API response headers, this class heuristically determines
 * whether a payload would have been served from the provider's cache — and estimates
 * the financial savings accordingly.
 *
 * Provider Cache TTLs and Discount Rates (as of 2025):
 *  - Anthropic (Claude): 5-minute TTL, 90% discount on cache reads
 *  - OpenAI (GPT-4o):    10-minute TTL, 50% discount on cached prompt tokens
 *  - Google (Gemini):    Sliding window, 75% discount on cached tokens
 *  - Default fallback:   50% discount
 */

export interface CacheProviderProfile {
    ttlMs: number;          // Cache time-to-live in milliseconds
    discountRate: number;   // Fraction of cost saved on a cache hit (0–1)
}

export interface CacheSavingsResult {
    isHit: boolean;
    estimatedTokensSaved: number;
    estimatedDollarsSaved: number;
}

export class CacheSimulator {
    private static instance: CacheSimulator;

    // Map of fileHash -> last seen timestamp (ms)
    private hashTimestamps: Map<string, number> = new Map();

    // Known provider profiles keyed by model name fragment
    private readonly PROVIDER_PROFILES: Record<string, CacheProviderProfile> = {
        'claude':      { ttlMs: 5 * 60 * 1000,  discountRate: 0.90 },
        'gpt-4o':      { ttlMs: 10 * 60 * 1000, discountRate: 0.50 },
        'gpt-4':       { ttlMs: 10 * 60 * 1000, discountRate: 0.50 },
        'o1':          { ttlMs: 10 * 60 * 1000, discountRate: 0.50 },
        'gemini':      { ttlMs: 10 * 60 * 1000, discountRate: 0.75 },
        'default':     { ttlMs: 5 * 60 * 1000,  discountRate: 0.50 },
    };

    // Model-specific pricing (USD per 1M input tokens) — mirrors SavingsTracker
    private readonly PRICING_REGISTRY: Record<string, number> = {
        'claude-3-5-sonnet': 3.00,
        'claude-3-opus':     15.00,
        'claude-3-haiku':    0.25,
        'gpt-4o':            5.00,
        'gpt-4o-mini':       0.15,
        'gpt-4-turbo':       10.00,
        'gpt-3.5-turbo':     0.50,
        'gemini-1.5-pro':    3.50,
        'gemini-1.5-flash':  0.35,
        'default':           3.00,
    };

    private constructor() {}

    public static getInstance(): CacheSimulator {
        if (!CacheSimulator.instance) {
            CacheSimulator.instance = new CacheSimulator();
        }
        return CacheSimulator.instance;
    }

    /**
     * Records a payload hash and returns whether it constitutes a provider cache hit.
     * A hit occurs when the same hash was seen within the provider's TTL window.
     */
    public checkAndRecord(payloadHash: string, model: string = 'default'): boolean {
        const profile = this.resolveProfile(model);
        const now = Date.now();
        const lastSeen = this.hashTimestamps.get(payloadHash);

        const isHit = lastSeen !== undefined && (now - lastSeen) < profile.ttlMs;

        // Always update the timestamp to keep the TTL window rolling
        this.hashTimestamps.set(payloadHash, now);

        return isHit;
    }

    /**
     * Estimates the financial savings for a cache hit on a given token count and model.
     */
    public estimateSavings(compressedTokens: number, model: string = 'default'): CacheSavingsResult {
        const profile = this.resolveProfile(model);
        const pricing = this.resolvePricing(model);

        // Tokens "saved" is the discount fraction of the compressed payload
        const estimatedTokensSaved = Math.floor(compressedTokens * profile.discountRate);
        const estimatedDollarsSaved = (estimatedTokensSaved / 1_000_000) * pricing;

        return {
            isHit: true,
            estimatedTokensSaved,
            estimatedDollarsSaved,
        };
    }

    /**
     * Convenience: hashes a string payload deterministically for cache key generation.
     * Uses a fast djb2-style hash — not cryptographic, just for identity matching.
     */
    public hashPayload(payload: string): string {
        let hash = 5381;
        for (let i = 0; i < payload.length; i++) {
            hash = ((hash << 5) + hash) ^ payload.charCodeAt(i);
            hash |= 0; // Keep as 32-bit integer
        }
        return hash.toString(16);
    }

    /**
     * Clears all cached hash timestamps. Call between sessions or on extension restart.
     */
    public clearSession(): void {
        this.hashTimestamps.clear();
    }

    private resolveProfile(model: string): CacheProviderProfile {
        const m = model.toLowerCase();
        for (const [key, profile] of Object.entries(this.PROVIDER_PROFILES)) {
            if (m.includes(key) && profile) return profile;
        }
        return this.PROVIDER_PROFILES['default']!;
    }

    private resolvePricing(model: string): number {
        const m = model.toLowerCase();
        for (const [key, price] of Object.entries(this.PRICING_REGISTRY)) {
            if (m.includes(key) && price !== undefined) return price;
        }
        return this.PRICING_REGISTRY['default']!;
    }
}
