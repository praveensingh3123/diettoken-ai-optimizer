export class PromptCompressor {
    private static readonly FILLER_WORDS = [
        'please', 'could you', 'can you', 'would you', 'i want to', 'i would like to',
        'kindly', 'help me', 'assist me in', 'go ahead and', 'basically', 'actually',
        'simply', 'just', 'the', 'a', 'an', 'some', 'any', 'very', 'really', 'actually'
    ];

    private static readonly REDUNDANT_PHRASES = [
        /in the (?:codebase|project|repository)/gi,
        /specifically (?:in|for)/gi,
        /thank you/gi,
        /thanks/gi,
        /\bhi\b/gi,
        /\bhello\b/gi,
        /\bhey\b/gi
    ];

    public static compress(text: string): string {
        // 1. Protect code blocks (triple backticks OR File: injection blocks)
        const codeBlocks: string[] = [];
        let protectedText = text.replace(/(?:```[\s\S]*?```|^File: [\/\\].*?\n[\s\S]*?(?=\nFile:|$))/gm, (match) => {
            codeBlocks.push(match);
            return `__CODE_BLOCK_${codeBlocks.length - 1}__`;
        });

        // 2. Remove redundant phrases
        for (const phrase of this.REDUNDANT_PHRASES) {
            protectedText = protectedText.replace(phrase, '');
        }

        // 3. Remove filler words (only if they are standalone words)
        for (const word of this.FILLER_WORDS) {
            const regex = new RegExp(`\\b${word}\\b`, 'gi');
            protectedText = protectedText.replace(regex, '');
        }

        // 4. Restore code blocks
        let final = protectedText.replace(/__CODE_BLOCK_(\d+)__/g, (match, p1) => {
            const index = parseInt(p1, 10);
            return codeBlocks[index] || match;
        });

        // 5. Clean up extra spaces and punctuation
        final = final
            .replace(/\s+/g, ' ')
            .replace(/\s+([,.!?])/g, '$1')
            .trim();

        return final;
    }

    /**
     * More aggressive compression (Caveman-speak)
     */
    public static cavemanSpeak(text: string): string {
        return this.compress(text)
            .toLowerCase()
            .replace(/\b(is|am|are|was|were|be|been|being)\b/gi, '') // Remove auxiliary verbs
            .replace(/\s+/g, ' ')
            .trim();
    }
}
