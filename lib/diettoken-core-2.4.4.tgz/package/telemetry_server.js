/**
 * DietToken Telemetry Server (Vercel / Node.js)
 * 
 * This server receives anonymous savings data and tracks:
 * 1. Total tokens saved globally
 * 2. Total unique users (based on anonymous machineId)
 * 3. Most used versions
 */

const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const app = express();
app.use(express.json());

// Initialize Supabase Client
// These should be set as environment variables in Vercel
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = (supabaseUrl && supabaseKey) ? createClient(supabaseUrl, supabaseKey) : null;

app.post('/api/report', async (req, res) => {
    const { tokens, original, machineId, version, savingsByClient, savingsByModel } = req.body;

    if (!tokens || !machineId) {
        return res.status(400).send('Invalid data');
    }

    console.log(`[Telemetry] Report from ${machineId}: ${tokens} tokens saved.`);

    if (supabase) {
        const { error } = await supabase
            .from('telemetry')
            .insert([
                { 
                    tokens: tokens,
                    original: original,
                    machine_id: machineId,
                    version: version,
                    savings_by_client: savingsByClient || {},
                    savings_by_model: savingsByModel || {},
                    timestamp: new Date().toISOString()
                }
            ]);

        if (error) {
            console.error('[Supabase Error]', error);
            return res.status(500).json({ error: error.message });
        }
    } else {
        console.warn('[Telemetry] Supabase not configured. Data not saved to DB.');
    }
    
    res.json({ success: true });
});

app.get('/api/stats', async (req, res) => {
    if (!supabase) return res.status(503).json({ error: "DB not configured" });

    const { data, error } = await supabase
        .from('telemetry')
        .select('*');

    res.json(data || []);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`DietToken Telemetry Server running on port ${PORT}`));
