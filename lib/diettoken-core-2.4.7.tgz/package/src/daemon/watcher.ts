import * as fs from 'fs';
import * as path from 'path';
import { KnowledgeGraph } from '../graph/KnowledgeGraph';

// Minimal Zero-Network Daemon using native fs.watch
export class DietTokenDaemon {
    private watchDir: string;
    private cacheDir: string;
    private debounceTimer: NodeJS.Timeout | null = null;
    private graph: KnowledgeGraph;

    constructor(watchDir: string) {
        this.watchDir = path.resolve(watchDir);
        this.cacheDir = path.join(this.watchDir, '.diettoken');
        this.graph = KnowledgeGraph.getInstance();
    }

    public async start() {
        if (!fs.existsSync(this.cacheDir)) {
            fs.mkdirSync(this.cacheDir, { recursive: true });
        }

        console.log(`[DietToken Daemon] Starting Zero-Network watcher in: ${this.watchDir}`);
        
        await this.graph.initialize(this.watchDir);

        try {
            // Recursive watch works out of the box on Windows and MacOS
            fs.watch(this.watchDir, { recursive: true }, (eventType, filename) => {
                if (!filename || filename.includes('.git') || filename.includes('node_modules') || filename.includes('.diettoken')) {
                    return;
                }

                // Debounce changes (e.g. from git pull)
                if (this.debounceTimer) {
                    clearTimeout(this.debounceTimer);
                }

                this.debounceTimer = setTimeout(() => {
                    this.recalculateGraph();
                }, 400); // 400ms debounce
            });
            console.log(`[DietToken Daemon] Listening for file saves and git pulls...`);
        } catch (e: any) {
            console.error(`[DietToken Daemon] Failed to start native watcher: ${e.message}`);
        }
    }

    private async recalculateGraph() {
        console.log(`[DietToken Daemon] File changes detected. Deterministically recalculating AST graph...`);
        const startTime = Date.now();
        
        try {
            // In a full implementation, this would only parse changed files.
            // For now, we simulate the full pass or rely on the KnowledgeGraph's internal caching
            await this.graph.initialize(this.watchDir); 
            
            const cacheFile = path.join(this.cacheDir, 'cache.json');
            // We just touch the cache file to indicate readiness, or serialize the graph if needed
            fs.writeFileSync(cacheFile, JSON.stringify({ 
                lastUpdated: Date.now(),
                status: 'synced',
                message: 'Deterministic local compute completed.'
            }));

            console.log(`[DietToken Daemon] Graph recalculated in ${Date.now() - startTime}ms.`);
        } catch (e: any) {
            console.error(`[DietToken Daemon] Recalculation failed: ${e.message}`);
        }
    }
}

// Start immediately if invoked directly
if (require.main === module) {
    const daemon = new DietTokenDaemon(process.cwd());
    daemon.start();
}
