import { parentPort } from 'worker_threads';
import * as TreeSitter from 'web-tree-sitter';
import * as path from 'path';

let parser: TreeSitter.Parser | null = null;
let extPath = '';
const loadedLanguages: Record<string, TreeSitter.Language> = {};

async function initParser(extensionPath: string) {
    if (parser) return;
    try {
        extPath = extensionPath;
        await TreeSitter.Parser.init({
            locateFile(scriptName: string) {
                return path.join(extensionPath, 'node_modules', 'web-tree-sitter', scriptName);
            },
        });
        parser = new TreeSitter.Parser();
        parentPort?.postMessage({ type: 'ready' });
    } catch (e: any) {
        parentPort?.postMessage({ type: 'error', error: e.message });
    }
}

function getWasmName(ext: string): string {
    switch (ext) {
        case '.py': return 'tree-sitter-python.wasm';
        case '.go': return 'tree-sitter-go.wasm';
        case '.java': return 'tree-sitter-java.wasm';
        case '.rs': return 'tree-sitter-rust.wasm';
        case '.cpp':
        case '.cc':
        case '.cxx': return 'tree-sitter-cpp.wasm';
        case '.c': return 'tree-sitter-c.wasm';
        case '.cs': return 'tree-sitter-c_sharp.wasm';
        case '.rb': return 'tree-sitter-ruby.wasm';
        case '.php': return 'tree-sitter-php.wasm';
        case '.swift': return 'tree-sitter-swift.wasm';
        case '.js':
        case '.jsx': return 'tree-sitter-javascript.wasm';
        case '.ts':
        case '.tsx':
        default:
            return 'tree-sitter-typescript.wasm';
    }
}

async function parseCode(id: string, sourceCode: string, filePath?: string) {
    if (!parser) {
        parentPort?.postMessage({ id, error: 'Parser not initialized' });
        return;
    }
    try {
        const ext = filePath ? path.extname(filePath).toLowerCase() : '.ts';
        const wasmName = getWasmName(ext);
        
        if (!loadedLanguages[wasmName]) {
            const wasmPath = path.join(extPath, 'node_modules', '@repomix', 'tree-sitter-wasms', 'out', wasmName);
            const lang = await TreeSitter.Language.load(wasmPath);
            loadedLanguages[wasmName] = lang;
        }
        
        parser.setLanguage(loadedLanguages[wasmName]);
        const tree = parser.parse(sourceCode);
        
        if (!tree) {
            parentPort?.postMessage({ id, error: 'Failed to parse code' });
            return;
        }
        
        const imports: string[] = [];
        const exports: string[] = [];
        const comments: { start: number, end: number }[] = [];
        const blocks: { start: number, end: number }[] = [];
        
        const cursor = tree.walk();
        const traverse = (c: TreeSitter.TreeCursor) => {
            const type = c.nodeType;
            if (type === 'import_statement' || type === 'import_from_statement') {
                imports.push(c.nodeText);
            }
            if (type.includes('export')) {
                exports.push(c.nodeText);
            }
            if (type === 'comment' || type === 'line_comment' || type === 'block_comment') {
                comments.push({ start: c.startIndex, end: c.endIndex });
            }
            if (type === 'expression_statement') {
                if (c.currentNode.childCount === 1 && c.currentNode.firstChild?.type === 'string') {
                    comments.push({ start: c.startIndex, end: c.endIndex });
                }
            }
            
            // Implementation blocks across different languages
            if (['statement_block', 'class_body', 'block'].includes(type)) {
                const parentType = c.currentNode.parent?.type || '';
                if (parentType.includes('function') || parentType.includes('method') || parentType.includes('class')) {
                    blocks.push({ start: c.startIndex, end: c.endIndex });
                }
            }
            
            if (c.gotoFirstChild()) {
                do { traverse(c); } while (c.gotoNextSibling());
                c.gotoParent();
            }
        };
        traverse(cursor);

        // Fallback for non-TS languages where AST yields 0 imports
        if (imports.length === 0) {
            const multilinePython = /^(?:from|import)\s+[\w.]+\s+import\s+\([\s\S]*?\)/gm;
            let match;
            while ((match = multilinePython.exec(sourceCode)) !== null) {
                imports.push(match[0].trim());
            }
            const singleLineRegex = /^(?:import|from)\b.*$/gm;
            while ((match = singleLineRegex.exec(sourceCode)) !== null) {
                if (!imports.some(imp => imp.includes(match![0].trim()))) {
                    imports.push(match[0].trim());
                }
            }
        }

        parentPort?.postMessage({ id, imports, exports, comments, blocks });
    } catch (e: any) {
        parentPort?.postMessage({ id, error: e.message });
    }
}

parentPort?.on('message', async (message) => {
    if (message.type === 'init') {
        await initParser(message.extensionPath);
    } else if (message.type === 'parse') {
        await parseCode(message.id, message.sourceCode, message.filePath);
    }
});
