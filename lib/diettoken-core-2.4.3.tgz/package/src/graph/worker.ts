import { parentPort } from 'worker_threads';
import * as TreeSitter from 'web-tree-sitter';
import * as path from 'path';

let parser: TreeSitter.Parser | null = null;

async function initParser(extensionPath: string) {
    if (parser) return;
    try {
        await TreeSitter.Parser.init({
            locateFile(scriptName: string) {
                return path.join(extensionPath, 'node_modules', 'web-tree-sitter', scriptName);
            },
        });
        parser = new TreeSitter.Parser();
        const wasmPath = path.join(extensionPath, 'node_modules', '@repomix', 'tree-sitter-wasms', 'out', 'tree-sitter-typescript.wasm');
        const lang = await TreeSitter.Language.load(wasmPath);
        parser.setLanguage(lang);
        parentPort?.postMessage({ type: 'ready' });
    } catch (e: any) {
        parentPort?.postMessage({ type: 'error', error: e.message });
    }
}

function parseCode(id: string, sourceCode: string) {
    if (!parser) {
        parentPort?.postMessage({ id, error: 'Parser not initialized' });
        return;
    }
    try {
        const tree = parser.parse(sourceCode);
        if (!tree) {
            parentPort?.postMessage({ id, error: 'Failed to parse code' });
            return;
        }
        const imports: string[] = [];
        const exports: string[] = [];
        const comments: { start: number, end: number }[] = [];
        const blocks: { start: number, end: number }[] = [];
        
        const cursor = tree.walk();
        const traverse = (c: TreeSitter.TreeCursor) => {
            if (c.nodeType === 'import_statement') {
                imports.push(c.nodeText);
            }
            if (c.nodeType.includes('export')) {
                exports.push(c.nodeText);
            }
            if (c.nodeType === 'comment') {
                comments.push({ start: c.startIndex, end: c.endIndex });
            }
            // Implementation blocks in TS/JS
            if (['statement_block', 'class_body'].includes(c.nodeType)) {
                // We only want to strip if the parent is a function or class
                const parentType = c.currentNode.parent?.type || '';
                if (parentType.includes('function') || parentType.includes('method') || parentType.includes('class')) {
                    blocks.push({ start: c.startIndex, end: c.endIndex });
                }
            }
            
            if (c.gotoFirstChild()) {
                do {
                    traverse(c);
                } while (c.gotoNextSibling());
                c.gotoParent();
            }
        };
        traverse(cursor);

        // Fallback for non-TS languages (like Python) where AST yields 0 imports
        if (imports.length === 0) {
            // Match single-line and multi-line (parentheses or braces) imports
            const importRegex = /^(?:import\s+[\s\S]*?|from\s+[\w.]+\s+import\s+[\s\S]*?|const\s+.*=\s+require\([\s\S]*?\))(?:$|\n|\))/gm;
            const multilinePython = /^(?:from|import)\s+[\w.]+\s+import\s+\([\s\S]*?\)/gm;
            
            // Try multi-line python first
            let match;
            while ((match = multilinePython.exec(sourceCode)) !== null) {
                imports.push(match[0].trim());
            }

            // Then catch remaining single lines
            const singleLineRegex = /^(?:import|from)\b.*$/gm;
            while ((match = singleLineRegex.exec(sourceCode)) !== null) {
                if (!imports.some(imp => imp.includes(match![0].trim()))) {
                    imports.push(match[0].trim());
                }
            }
        }

        parentPort?.postMessage({ id, imports, exports, comments, blocks });
    } catch (e: any) {
        parentPort?.postMessage({ id, error: e.message });
    }
}

parentPort?.on('message', async (message) => {
    if (message.type === 'init') {
        await initParser(message.extensionPath);
    } else if (message.type === 'parse') {
        parseCode(message.id, message.sourceCode);
    }
});
