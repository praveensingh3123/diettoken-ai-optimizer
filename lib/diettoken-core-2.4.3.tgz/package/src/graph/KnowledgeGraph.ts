import * as vscode from 'vscode';
import * as fs from 'fs';
import { Worker } from 'worker_threads';
import * as path from 'path';

export class KnowledgeGraph {
    private worker: Worker | null = null;
    private static instance: KnowledgeGraph;
    
    // In-memory graph nodes (file path -> dependencies)
    private dependencyGraph: Map<string, { imports: string[], exports: string[] }> = new Map();
    private sessionHashes: Map<string, string> = new Map(); // path -> hash
    
    private pendingRequests: Map<string, { resolve: Function, reject: Function }> = new Map();

    private constructor() {}

    public static getInstance(): KnowledgeGraph {
        if (!KnowledgeGraph.instance) {
            KnowledgeGraph.instance = new KnowledgeGraph();
        }
        return KnowledgeGraph.instance;
    }

    public async initialize(extensionPath: string) {
        if (this.worker) return;

        return new Promise<void>((resolve, reject) => {
            const isTs = __filename.endsWith('.ts');
            const workerPath = path.join(__dirname, isTs ? 'worker.ts' : 'worker.js');
            
            const workerOptions: any = {};
            // If running tests directly from TS, ensure the worker can parse TS
            if (isTs) {
                workerOptions.execArgv = ['--import', 'tsx'];
            }

            this.worker = new Worker(workerPath, workerOptions);
            
            this.worker.on('message', (msg) => {
                if (msg.type === 'ready') {
                    console.error("Tree-sitter WASM loaded in Worker Thread successfully");
                    resolve();
                } else if (msg.type === 'error' && !this.pendingRequests.has(msg.id)) {
                    console.error("Worker error:", msg.error);
                    reject(new Error(msg.error));
                } else if (msg.id && this.pendingRequests.has(msg.id)) {
                    const req = this.pendingRequests.get(msg.id)!;
                    this.pendingRequests.delete(msg.id);
                    if (msg.error) {
                        req.reject(new Error(msg.error));
                    } else {
                        req.resolve({ imports: msg.imports, exports: msg.exports, comments: msg.comments, blocks: msg.blocks });
                    }
                }
            });

            this.worker.on('error', (err) => {
                console.error("Worker thread crashed:", err);
            });

            this.worker.postMessage({ type: 'init', extensionPath });
        });
    }

    public async parseCode(sourceCode: string): Promise<{ imports: string[], exports: string[], comments: {start: number, end: number}[], blocks: {start: number, end: number}[] }> {
        if (!this.worker) throw new Error("Worker not initialized");
        const id = Math.random().toString(36).substring(7);
        
        return new Promise((resolve, reject) => {
            this.pendingRequests.set(id, { resolve, reject });
            this.worker!.postMessage({ type: 'parse', id, sourceCode });
        });
    }

    public async updateFileNode(filePath: string, sourceCode: string) {
        try {
            const { imports, exports } = await this.parseCode(sourceCode);
            this.dependencyGraph.set(filePath, { imports, exports });
        } catch (e) {
            console.error("Failed to parse file for graph:", filePath, e);
        }
    }

    public getFileDependencies(filePath: string) {
        return this.dependencyGraph.get(filePath) || { imports: [], exports: [] };
    }

    /**
     * Finds related files (callers and callees) to provide contextual skeletons.
     */
    public getRelatedContext(filePath: string, depth: number = 1): string[] {
        const related = new Set<string>();
        const queue: { path: string, d: number }[] = [{ path: filePath, d: 0 }];
        const visited = new Set<string>();

        while (queue.length > 0) {
            const { path: currentPath, d } = queue.shift()!;
            if (visited.has(currentPath) || d > depth) continue;
            visited.add(currentPath);

            const deps = this.dependencyGraph.get(currentPath);
            if (deps) {
                // Add callees (files this file imports from)
                for (const imp of deps.imports) {
                    // Simple heuristic to resolve local imports (this could be improved with path resolution)
                    if (imp.startsWith('.') || imp.startsWith('/')) {
                        related.add(imp);
                        queue.push({ path: imp, d: d + 1 });
                    }
                }

                // Add callers (files that import this file)
                for (const [otherPath, otherDeps] of this.dependencyGraph.entries()) {
                    if (otherDeps.imports.some(imp => imp.includes(path.basename(currentPath)))) {
                        related.add(otherPath);
                        queue.push({ path: otherPath, d: d + 1 });
                    }
                }
            }
        }

        related.delete(filePath); // Don't include the file itself
        return Array.from(related);
    }

    /**
     * Identifies a "Feature Cluster" - a group of files that are highly interconnected.
     * Heuristic: Files that import from or are imported by the target file.
     */
    public getFeatureCluster(filePath: string): string[] {
        const cluster = new Set<string>();
        const deps = this.dependencyGraph.get(filePath);
        if (!deps) return [];

        const dir = path.dirname(filePath);

        // Direct dependencies
        deps.imports.forEach(imp => {
            let resolved = imp;
            if (imp.startsWith('.')) {
                resolved = path.resolve(dir, imp);
                // Heuristic: check common extensions if the resolved path doesn't exist
                const extensions = ['', '.ts', '.js', '.tsx', '.jsx', '.py', '.go'];
                for (const ext of extensions) {
                    if (fs.existsSync(resolved + ext)) {
                        resolved += ext;
                        break;
                    }
                }
            }
            if (path.isAbsolute(resolved)) {
                cluster.add(resolved);
            }
        });

        // Direct dependents (files that import this file)
        const baseName = path.basename(filePath).replace(/\.[^/.]+$/, ""); // strip extension
        for (const [otherPath, otherDeps] of this.dependencyGraph.entries()) {
            if (otherDeps.imports.some(imp => imp.includes(baseName))) {
                cluster.add(otherPath);
            }
        }

        return Array.from(cluster);
    }

    public clearSession() {
        this.sessionHashes.clear();
    }

    /**
     * Extracts a specific function's source text plus the signatures of its direct callees.
     * This is the Dependency Slice — the surgical alternative to full file skeletonization.
     * Returns a formatted string ready to be sent as LLM context.
     */
    public getFunctionSlice(filePath: string, functionName: string, sourceCode: string): string {
        const lines = sourceCode.split('\n');
        const totalLines = lines.length;

        // Heuristic: scan for function/method definition matching the name
        // Works for Python (def), TypeScript/JS (function keyword, arrow, class method)
        const defPatterns = [
            new RegExp(`^\\s*(async\\s+)?function\\s+${functionName}\\s*\\(`),       // TS/JS function
            new RegExp(`^\\s*(public|private|protected)?\\s*(async\\s+)?${functionName}\\s*\\(`), // class method
            new RegExp(`^\\s*(const|let|var)\\s+${functionName}\\s*=\\s*(async\\s*)?\\(`),       // arrow
            new RegExp(`^\\s*def\\s+${functionName}\\s*\\(`),                           // Python
        ];

        let startLine = -1;
        for (let i = 0; i < totalLines; i++) {
            const line = lines[i];
            if (line && defPatterns.some(p => p.test(line))) {
                startLine = i;
                break;
            }
        }

        if (startLine === -1) return '';

        // Walk forward to find the end of the function (brace counting for TS/JS, indent for Python)
        let endLine = startLine;
        let braceDepth = 0;
        let foundOpenBrace = false;
        for (let i = startLine; i < totalLines; i++) {
            const line = lines[i];
            if (!line) continue;
            for (const ch of line) {
                if (ch === '{') { braceDepth++; foundOpenBrace = true; }
                if (ch === '}') { braceDepth--; }
            }
            if (foundOpenBrace && braceDepth === 0) {
                endLine = i;
                break;
            }
        }

        const functionBody = lines.slice(startLine, endLine + 1).join('\n');
        const calleeSummary = this.extractCalleeSummaries(functionBody, lines);

        return [
            `[DietToken Function Slice: ${functionName} from ${path.basename(filePath)}]`,
            functionBody,
            calleeSummary ? `\n[Direct Callees Signatures]\n${calleeSummary}` : ''
        ].join('\n');
    }

    /**
     * Given a function body string, find any calls to other locally-defined functions
     * and return their one-line signatures from the source lines.
     */
    private extractCalleeSummaries(functionBody: string, allLines: string[]): string {
        const callPattern = /\b([a-zA-Z_][a-zA-Z0-9_]*)\s*\(/g;
        const callees = new Set<string>();
        let m;
        while ((m = callPattern.exec(functionBody)) !== null) {
            if (m[1]) callees.add(m[1]);
        }

        const signatures: string[] = [];
        for (const callee of callees) {
            const defPatterns = [
                new RegExp(`^\\s*(async\\s+)?function\\s+${callee}\\s*\\(.*\\)`),
                new RegExp(`^\\s*(public|private|protected)?\\s*(async\\s+)?${callee}\\s*\\(.*\\)`),
                new RegExp(`^\\s*def\\s+${callee}\\s*\\(.*\\):`),
            ];
            for (const line of allLines) {
                if (line && defPatterns.some(p => p.test(line))) {
                    signatures.push(line.trim());
                    break;
                }
            }
        }
        return signatures.join('\n');
    }

    public isFileUnchanged(filePath: string, currentContent: string): boolean {
        const hash = this.simpleHash(currentContent);
        const lastHash = this.sessionHashes.get(filePath);
        if (lastHash === hash) return true;
        
        this.sessionHashes.set(filePath, hash);
        return false;
    }

    private simpleHash(str: string): string {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0; // Convert to 32bit integer
        }
        return hash.toString();
    }
}
