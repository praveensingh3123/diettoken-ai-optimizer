import { KnowledgeGraph } from '../graph/KnowledgeGraph';
import { ReverseMapper } from './ReverseMapper';

export class AstCompressor {
    private reverseMapper: ReverseMapper;

    constructor(reverseMapper: ReverseMapper) {
        this.reverseMapper = reverseMapper;
    }

    public async compress(sourceCode: string, mode?: 'full' | 'skeleton', filePath?: string): Promise<string> {
        let effectiveMode = mode;
        if (!effectiveMode) {
            const lineCount = sourceCode.split('\n').length;
            effectiveMode = lineCount > 500 ? 'skeleton' : 'full';
        }

        // 0. Cavemem Check: If file is unchanged since last turn, prune it
        if (filePath && effectiveMode === 'full') {
            const graph = KnowledgeGraph.getInstance();
            if (graph.isFileUnchanged(filePath, sourceCode)) {
                return `[DietToken Memory: File ${filePath} unchanged, using context from previous turn]`;
            }
        }
        // 1. Protect <ext_safe> blocks
        const safeBlocks: string[] = [];
        let safeCode = sourceCode.replace(/<ext_safe>([\s\S]*?)<\/ext_safe>/g, (match) => {
            safeBlocks.push(match);
            return `«S${safeBlocks.length - 1}»`;
        });

        // Protect multi-line Python imports with parentheses
        safeCode = safeCode.replace(/^(?:from|import)\s+[\w.]+\s+import\s+\([\s\S]*?\)/gm, (match) => {
            safeBlocks.push(match);
            return `«S${safeBlocks.length - 1}»`;
        });

        // Protect multi-line TS/JS imports with curly braces
        safeCode = safeCode.replace(/^import\s+[\s\S]*?\{[\s\S]*?\}\s+from\s+['"].*?['"]/gm, (match) => {
            safeBlocks.push(match);
            return `«S${safeBlocks.length - 1}»`;
        });

        // Protect all remaining single-line import/export statements
        safeCode = safeCode.replace(/^(?:import|export|from)\b.*$/gm, (match) => {
            if (match.includes('«S')) return match; // Avoid double-wrapping
            safeBlocks.push(match);
            return `«S${safeBlocks.length - 1}»`;
        });

        // 1.5. Boilerplate Banisher: strip typed JSDoc tags and standard library imports
        safeCode = this.stripBoilerplate(safeCode, safeBlocks);

        const graph = KnowledgeGraph.getInstance();
        let comments: {start: number, end: number}[] = [];
        let blocks: {start: number, end: number}[] = [];
        try {
            const result = await graph.parseCode(safeCode);
            comments = result.comments;
            blocks = result.blocks;
        } catch (e) {
            console.error("Worker parsing failed, skipping AST compression", e);
        }

        // 3. Slice out comments (must be done in reverse order to preserve string offsets!)
        const itemsToStrip = [...comments];
        
        if (effectiveMode === 'skeleton') {
            // Add implementation blocks to the strip list
            for (const block of blocks) {
                itemsToStrip.push({ start: block.start, end: block.end, type: 'block' } as any);
            }
        }

        itemsToStrip.sort((a, b) => b.start - a.start);
        
        for (const item of itemsToStrip) {
            if ((item as any).type === 'block') {
                // For blocks, we replace with a placeholder to maintain syntax correctness
                safeCode = safeCode.substring(0, item.start) + "{ /* implementation stripped */ }" + safeCode.substring(item.end);
            } else {
                safeCode = safeCode.substring(0, item.start) + safeCode.substring(item.end);
            }
        }

        // 4. Strip redundant whitespaces (collapse multiple blank lines)
        safeCode = safeCode.replace(/[ \t]+$/gm, ''); // Remove trailing whitespace
        safeCode = safeCode.replace(/\n\s*\n/g, '\n');

        // 5. Level 2 Semantic Compression (Variable renaming) has been disabled 
        // to preserve domain semantic integrity for high-stakes code generation.

        // 6. Restore protected blocks
        safeCode = safeCode.replace(/«S(\d+)»/g, (match, p1) => {
            const index = parseInt(p1, 10);
            return safeBlocks[index] || match;
        });

        return safeCode;
    }

    /**
     * Boilerplate Banisher: removes high-noise, low-information content that
     * wastes LLM token budget without contributing semantic meaning.
     *
     * Rules:
     * 1. Strip JSDoc typed tags (@param, @returns, @throws, @author, @version, @type)
     *    that duplicate TypeScript/Python type annotations visible in the signature.
     *    @deprecated tags are KEPT — they carry unique semantic warnings.
     * 2. Strip standard library / well-known third-party import «S» placeholders that
     *    are not local project imports (i.e., don't start with . or @/).
     *    We restore them from safeBlocks, inspect, and replace with a compact summary.
     */
    private stripBoilerplate(code: string, safeBlocks: string[]): string {
        let result = code;

        // Rule 1: Strip JSDoc typed tags (keep @deprecated)
        // Matches lines inside block comments: " * @param foo {string} Description"
        result = result.replace(/^[ \t]*\*[ \t]*@(?:param|returns?|throws?|author|version|type|since|memberof|access|public|private|protected|override|readonly|abstract|static|namespace|module|class|interface|enum|function|constructor)\b[^\n]*/gm, '');

        // Rule 2: Collapse safeBlock imports that are standard library / known packages
        // We inspect each «S» placeholder; if the original import is not a local path, 
        // replace it with a compact [import omitted] marker to save tokens.
        result = result.replace(/«S(\d+)»/g, (match, p1) => {
            const index = parseInt(p1, 10);
            const original = safeBlocks[index] || '';
            // Keep local imports (start with . or / or @/) — they carry structural meaning
            const isLocal = /from\s+['"](\.|\/)/.test(original) ||
                            /from\s+['"]\./.test(original) ||
                            /import\s+['"](\.|\/)/.test(original);
            if (!isLocal && original.length > 0) {
                // Replace the safeBlock entry with a compact form so it renders small when restored
                safeBlocks[index] = `/* [imports omitted] */`;
            }
            return match; // Keep the placeholder — it will be restored later
        });

        return result;
    }
}
