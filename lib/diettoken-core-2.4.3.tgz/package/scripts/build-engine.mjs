import esbuild from 'esbuild';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function buildEngine() {
    console.log('Building DietToken Core Engine (Black Box)...');

    try {
        await esbuild.build({
            entryPoints: [path.resolve(__dirname, '../src/core.ts')],
            bundle: true,
            platform: 'node',
            target: 'node16',
            outfile: path.resolve(__dirname, '../out/core/diettoken-engine.js'),
            minify: true, // This is the "black box" obfuscation
            sourcemap: false,
            format: 'cjs',
            // Externalize things that shouldn't be bundled directly like tree-sitter bindings
            external: ['web-tree-sitter', '@repomix/tree-sitter-wasms', 'js-tiktoken'],
        });
        
        console.log('✅ Successfully built diettoken-engine.js');
    } catch (error) {
        console.error('❌ Build failed:', error);
        process.exit(1);
    }
}

buildEngine();
